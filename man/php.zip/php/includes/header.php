<!doctype html>
	<html>
		<head>
			<meta charset="utf_8"/>
				<title>صفحه اصلی </title>
					<link href="css/index.css" rel="stylesheet"
				type="text/css"/>
			<style type="text/css">
		<!--
				.set_style_link{
					text-decoration:none ;
					font-weight: bold;
				}
				-->		
		</style>
	</head>
<body>
	<div class ="divTable" >
		<div class="diveTableRow">
			<div class="diveTableCell">
				<header class ="divTable">
					<div class="diveTableRow">
					<div class="diveTableCell">
				</div>
			</div>
		</header>
	<nav class="divTable">
		<ul class="divTableRow">
			<li class="divTableCell"><a class="set_style_link"href="index.php">صفحه اصلی</a></li>
				<li class="divTableCell"><a class="set_style_link"href="register.php">عضویت</a></li>
					<li class="divTableCell"><a class="set_style_link"href="#">ورود</a></li>
						<li class="divTableCell"><a class="set_style_link"href="#">درباره</a></li>
						<li class="divTableCell"><a class="set_style_link"href="#">ارتباط</a></li>
					</ul>
			</nav>

<section class="divtable">
		<section class="divTableRow">
				