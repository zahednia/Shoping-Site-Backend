</section>
		</section>
</section>

<footer class= "divTable">
	<section class="divTableRow">
		<article class="diveTableCell">Copyright 2022 Korosh & Samyar Web Page</article>
	</section>
</footer>
			</div>
		</div>
	</div>
	</body>
</html>